create table year
(
year_id int primary key,
year int
);

create table semester
(
sem_id		int primary key,
sem_name	varchar(10),
year_id		int references year
);

create table student
(
st_id		varchar(10) primary key,
st_name		varchar(30),
st_fname	varchar(30),
sem_id  	int references semester,
st_contact	varchar(11),
st_gender	varchar(6),
st_address	varchar(100),
);

create table department
(
dep_id		int primary key,
st_id		varchar(10) REFERENCES student,
t_id		varchar(11) REFERENCES teacher,
dep_name    varchar(20)
);

create table teacher
(
t_id		varchar(11) primary key,
t_name		varchar(30),
t_email		varchar(20),
t_contact	varchar(11),
t_gender	varchar(6),
t_address	varchar(100),
t_salary	int
);

create table courses
(
c_id		varchar(10) primary key,
c_code		varchar(10),
c_name		varchar(20),
credit_hour	int,
st_id		varchar(10) REFERENCES student,
t_id		varchar(11) REFERENCES teacher

);

create table Attendence
(
Att_id		int primary key,
st_id		varchar(10) references student,
t_id		varchar(11) references teacher,
status		varchar(50)
);

create table transport
(
trans_id	varchar(11) primary key,
st_id		varchar(10) References student,
city		varchar(20),
rout_no		int,
stop_name	varchar(30),
trans_fee	int
);

create table result
(
R_id		int primary key,
st_id		varchar(10) references student,
cgpa		float
);

create table Fees
(
F_id		int primary key,
st_id		varchar(10) references student,
dep_id		int references department,
Fees		int
);

create table Quiz
(
q_id		int primary key,
c_id		varchar(10) references courses,
t_id		varchar(11) references teacher,
st_id		varchar(10) references student,
marks       int
);

create table Assignment
(
a_id		int primary key,
c_id		varchar(10) references courses,
t_id		varchar(11) references teacher,
st_id		varchar(10) references student,
marks       int
);