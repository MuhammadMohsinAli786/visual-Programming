# contact_system

Project: Contact Management System in PHP...
– To download Contact Management System project for free (scroll down)

About Project
Contact Management System project is written in PHP. This is a simple project which is very easy to understand and use. Talking about the system, it contains all the required functions which include adding, viewing, deleting and updating contact lists. While adding the contact of a person, he/she has to provide first name, last name, gender, address and contact details. The user can also update the contact list if he/she wants to. The system shows the contact details in a list view. And also the user easily delete any contact details.

This project Contact Management system provides the simplest management of contact details. In short, these projects mainly focus on CRUD. There’s an external database connection file used in this mini project to save user’s data permanently. In order to run the project, you must have installed XAMPP, on your PC. Contact Management System in PHP project with source code is free to download. Use for education purpose only! For the project demo, have a look at the YouTube video below.

How To Run??
After Starting Apache and MySQL in XAMPP, follow the following steps.

1st Step: Extract file
2nd Step: Copy the main project folder
3rd Step: Paste in xampp/htdocs/

Now Connecting Database
Open a browser and go to URL “http://localhost/phpmyadmin/”.
Then, click on the databases tab.
Create a database naming “contacts” and then click on the import tab.
Click on browse file and select “
contacts.sql” file which is inside “DATABASE” folder.
Click on go.
After Creating Database.
Open a browser and go to URL “http://localhost/contact_system. (folder name)


Thank You
