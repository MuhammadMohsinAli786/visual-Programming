create database grocery_store
create table customer
(
customer_ID int primary key,
name varchar(50),
contact_add int,
address int
);

create table shopping_Order
(
order_ID	int primary key,
customer_ID	int references customer,
date		varchar(50)
);

create table categories
(
cat_id		int primary key,
cat_name     varchar(30),
cat_type	varchar(30),

);

create table products
(
product_id	int primary key,
cat_id		int REFERENCES categories,
product_name    varchar(20)
);

create table seller
(
seller_id	int primary key,
product_id	int references products,
seller_name		varchar(20),

);

create table payment
(
payment_id	int primary key,
cat_id		int references categories,
date        varchar(50)
);

create table deliveries
(
del_id		int primary key,
customer_id	int references customer,
date		varchar(50)
);

create table transaction_report
(
trans_id	int primary key,
customer_id	int References customer,
order_id	int references shopping_order,
product_id	int references products,
payment_id	int references payment,
);
