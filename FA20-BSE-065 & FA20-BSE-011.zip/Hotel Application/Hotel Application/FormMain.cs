﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace Hotel_Application
{
    public partial class FormMain : Form
    {
        SqlConnection con = new SqlConnection(db.con);
        SqlCommand cm = new SqlCommand();
        SqlDataReader dr;
        public FormMain()
        {
            InitializeComponent();
            LoadRooms();
            LoadRoomsBooked();
            LoadRoomsAvailable();
            LoadGuest();


        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void FormMain_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dgvRooms_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string ColName = dgvRooms.Columns[e.ColumnIndex].Name;
            if (ColName == "ColDelete")
            {
                con.Open();
                cm = new SqlCommand("Delete from Rooms where id like'" + dgvRooms.CurrentRow.Cells[0].Value + "'", con);
                cm.ExecuteNonQuery();
                con.Close();
                LoadRooms();
                MessageBox.Show("Room has been Deleted Successfully");

            }
            if (ColName == "ColEdit")
            {
                txtRoomName.Text = dgvRooms.CurrentRow.Cells[2].Value.ToString();
                comboStatus.Text = dgvRooms.CurrentRow.Cells[3].Value.ToString();
                txtTypebed.Text = dgvRooms.CurrentRow.Cells[4].Value.ToString();
                txtPrice.Text = dgvRooms.CurrentRow.Cells[5].Value.ToString();
            }
        }
        public void LoadGuestBooked()
        {
            Dgvcheckin.Rows.Clear();
            int i = 0;
            con.Open();
            cm = new SqlCommand("select  * from checkin ", con);

            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                i++;
                Dgvcheckin.Rows.Add(dr[0], i,dr[1],dr[2],dr[3],dr[4],dr[5]);

            }
            con.Close();
        }
        public void LoadGuest()
        {
            DgvGuest.Rows.Clear();
            int i = 0;
            cm = new SqlCommand("select * from Guest", con);
            con.Open();
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                i++;
                DgvGuest.Rows.Add(dr[0], i, dr[1], dr[2], "Edit", "Delete");
                comboName.Items.Add(dr[1]);
            }
            con.Close();
        }
        public void LoadRooms()
        {
            dgvRooms.Rows.Clear();
            int i = 0;
            cm = new SqlCommand("select * from rooms", con);
            con.Open();
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                i++;
                dgvRooms.Rows.Add(dr[0], i, dr[1], dr[2],dr[3],dr[4]);
                
            }
            con.Close();
        }
        public void LoadRoomsBooked()
        {
            DgvRoomsBooked.Rows.Clear();
            int i = 0;
            cm = new SqlCommand("select * from rooms where Status='Booked'", con);
            con.Open();
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                i++;
                DgvRoomsBooked.Rows.Add(dr[0], i, dr[1], dr[2]);
            }
            con.Close();
        }

        public void LoadRoomsAvailable()
        {
            DgvRoomsAvailable.Rows.Clear();
            int i = 0;
            cm = new SqlCommand("select * from rooms where Status='Available'", con);
            con.Open();
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                i++;
                DgvRoomsAvailable.Rows.Add(dr[0], i, dr[1], dr[2]);
            }
            con.Close();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            cm = new SqlCommand("insert into rooms(RoomName,Status,TypeBed,Price) values(@RoomName,@Status,@TypeBed,@Price)", con);
            cm.Parameters.AddWithValue("@RoomName", txtRoomName.Text);
            cm.Parameters.AddWithValue("@Status", comboStatus.SelectedItem);
            cm.Parameters.AddWithValue("@TypeBed", txtTypebed.Text);
            cm.Parameters.AddWithValue("@Price", txtPrice.Text);

            con.Open();
            cm.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Record has been saved Successfully");
            LoadRooms();
            txtRoomName.Clear();
            comboStatus.Text = " ";
            txtRoomName.Focus();
           
        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }
        private void BtnAddGuest_Click(object sender, EventArgs e)
        {
            con.Open();
            cm = new SqlCommand("insert into Guest(GuestName,telephone) values(@GuestName,@telephone)", con);
            MemoryStream ms = new MemoryStream();
           

            cm.Parameters.AddWithValue("@GuestName", TxtGuestName.Text);
            cm.Parameters.AddWithValue("@telephone", TxtPhone.Text);
           
            cm.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Guest has been Saved Successfully");
           
            TxtGuestName.Clear();
            TxtPhone.Clear();
            TxtGuestName.Focus();
            LoadGuest();
        }

        private void DgvGuest_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string ColName = DgvGuest.Columns[e.ColumnIndex].Name;
            if (ColName == "ColDel")
            {
                con.Open();
                cm = new SqlCommand("Delete from Guest where id like'" + DgvGuest.CurrentRow.Cells[0].Value + "'", con);
                cm.ExecuteNonQuery();
                con.Close();
                LoadGuest();
                MessageBox.Show("Room has been Deleted Successfully");

            }
            if (ColName == "ColEdt")
            {
                TxtGuestName.Text = DgvGuest.CurrentRow.Cells[2].Value.ToString();
                TxtPhone.Text = dgvRooms.CurrentRow.Cells[3].Value.ToString();
                
            }

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void Dgvcheckin_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void DgvRoomsAvailable_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            con.Open();
            cm = new SqlCommand("Available rooms(RoomName=@RoomName,Status=@Status)", con);
            cm.Parameters.AddWithValue("@RoomName", txtRoomName.Text);
            cm.Parameters.AddWithValue("@Status", comboStatus.SelectedItem);
            
            cm.ExecuteNonQuery();
            con.Close(); 
            LoadRooms();
            txtRoomName.Clear();
            comboStatus.Text = " ";
            txtRoomName.Focus();
           
        }

        private void comboName_SelectedIndexChanged(object sender, EventArgs e)
        {
            con.Open();
            cm = new SqlCommand("Select * from Guest Where GuestName like '" + comboGuest2.Text + "'", con);
            dr = cm.ExecuteReader();
            dr.Read();
            if(dr.HasRows)
            {
                txtTypebed.Text = dr[3].ToString();
                txtPrice.Text = dr[4].ToString();



            }
            con.Close();
        }

        private void txtRoomName_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtTypebed_TextChanged(object sender, EventArgs e)
        {

        }

        private void DgvRoomsBooked_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            con.Open();
            cm = new SqlCommand("Booked rooms(RoomName=@RoomName,Status=@Status)", con);
            cm.Parameters.AddWithValue("@RoomName", txtRoomName.Text);
            cm.Parameters.AddWithValue("@Status", comboStatus.SelectedItem);

            cm.ExecuteNonQuery();
            con.Close();

            LoadRooms();
            txtRoomName.Clear();
            comboStatus.Text = " ";
            txtRoomName.Focus();
        }

        private void textBox9_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }
       
    }
}

