﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hotel_Application
{
    class db
    {

        public static string con = " Data Source=HAIER-PC;Initial Catalog=HMS;Integrated Security=True";
    }
}
